#include <iostream>
#include "accesoCuenta.h"
#include "autoRentMenu.h"


using namespace std;

int main () {
	if (login() == false) {
		return 1;
	}
	
 	Menu();
	 	
	return 0;
}

