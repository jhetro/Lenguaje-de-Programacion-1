#include <iostream>
#include "autoRentMenu.h"
#include "servicioCliente.h"
#include "autoRent.h"
#include "ventaAutomovil.h"


using namespace std;



	void Menu() {	
	bool salir = false;
	
	while(salir == false) {
		char opcion;
		
		cout << "**********MENU**********" << endl;
		cout << "************************" << endl;
		cout << endl;
		cout << "a - Servicios de Cliente" << endl;
		cout << "b - Servicio AutoRent" << endl;
		cout << "c - Ventas" << endl;
		cout << "s - Salir" << endl;
		
		cout << endl;
		cout << endl;				
		cout << "Seleccione el submenu por ingresar y presione enter --> ";
		cin >> opcion;
		
		switch(opcion) {
			case 'a':
				servicioCliente();
				break;	
			case 'b':
				autoRent();
				break;
			case'c':
				ventaAutomovil()
				break;
			case 's':
				salir = true;	
			default: 		
				break;
		}
		
		 system("CLS");		
	}
}

