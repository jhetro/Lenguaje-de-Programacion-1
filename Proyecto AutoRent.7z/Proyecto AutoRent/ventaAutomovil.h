void ventaAutomovil();
bool buscarautomovil(char* &codigoAutoRent, char* &Modelo,char* anio)
