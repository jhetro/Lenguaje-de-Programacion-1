#include <iostream>
#include "welcome.h"
#include "autoRentMenu.h"
#include "accesoCuenta.h"

using namespace std;




void welcome() {
	cout << "�SEAS BIENVENIDO! aaaaaa:" << endl;
		system("COLOR 06");
		cout << "  ________  ___   ____.____________.___         _________     \n\n";
		cout << " /  __  \ \|  |   | | |____  ______|__  \\  **| |        \\**  \n\n";
		cout<< " **********************************************| |  |\     \\**  \n\n";
		cout << "|  |__|  | |  |   | | |  ||  ||   //  \\ || **| |  \  \    /\**  \n\n";
		cout << "|  ____  | |  |   | | |  \\  \\  ||   || || **| |   \  \  / /**   \n\n";
		cout << "|  |  |  | \  \__/  | |   || ||  \\___// || **| |   |  / / /**     \n\n";
		cout<< " **********************************************| |   | /  \ \**      \n\n";
		cout << "|  |  |  | |\______/__/   ||_||\________ // **| |___| \___\ \**      \n\n";

	

	cout << endl;
	cout << endl;
	cout << endl;
}
 		
void saltosDeLinea(int ciclos) {
	for(int indice = 1; indice <= ciclos; indice ++) {
		cout << endl;
	}
}


