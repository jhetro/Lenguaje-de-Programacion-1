#include <iostream>
#include "autoRentMenu.h"
#include "servicioCliente.h"
#include "welcome.h"
#include "autoRent.h"

using namespace std;

string arregloClientes[5][2] = {
	{ "cl-01-001", "Andrea Duron"},
	{ "cl-01-002", "Elizabeth Aguilar"},
	{ "cl-01-003", "Melba Flores" },
	{ "cl-01-004", "Renato Alvarez" },
	{ "cl-01-005", "Joseph Hernandez" }
};


void servicioCliente() {
	system("cls");

	cout << "***********Clientes************" << endl;
	cout << "*******************************"  <<endl;
	cout << endl;
	
	bool salir = false;
	
	while(salir == false) {
		string opcion;
		cout << "presione 'S' mas enter para salir de esta pantalla" << endl;	
		cin >> opcion;
		
		if (opcion == "S" || opcion == "s") {
			salir = true;
		}
	}
}

bool cliente(char* &codigoC, char* &cliente) {
	while(true) {
		cout<<"***************";
		cout<<"BUSCAR CLIENTE";
		cout<<"***************";
		saltosDeLinea(2);		
		cout<<"Codigo del Cliente: ", codigo;
		
		for(int indice = 0; indice < 5; indice++) {		
			if (arregloClientes[indice][0] == codigo) {
				nombreCliente = arregloClientes[indice][1];
				mensajeEnConsola("--> " + Cliente);
				return true;
			}
		}		
			
		bool continuar = false;
		while(continuar == false) {
			system("cls");
			
			string opcion = "";
			mensajeConValorEnConsola("Codigo de cliente no encontrado, desea continuar buscando s/n? ", opcion);
			
			if (opcion == "s" || opcion == "S") {
				continuar = true;
				system("cls");
			}
			if (opcion == "n" || opcion == "N") {
				return false;
			}		
		}
	}
}

