#include <iostream>
#include "ventaAutomovil.h"
#include "autoRent.h"
#include "welcome.h"

using namespace std;

string arregloJuegos[5][3] = {
	{ "AT-001", "Masda III", "2001"},
	{ "AT-002", "Nissan Navara", "1995"},
	{ "AT-003", "Toyota HILUX", "2009"},
	{ "AT-004", "Mercedes Benz", "1994"},
	{ "AT-005", "Mustan","1964"},

};


void ventaAutomovil() {
	system("cls");
	
	cout << "**********Servicio AutoRent*********" << endl;
	cout << "************************************" << endl;
	cout << endl;
	
	bool salir = false;
	
	while(salir == false) {
		string opcion;
		cout << "presione [S] o [s] mas enter para salir de esta pantalla" << endl;	
		
		
		if (opcion == "S" || opcion == "s") {
			salir = true;
		}
	}
}

bool buscarautomovil(char* &codigoAutoRent, char* &Modelo,char* &anio) {
	while(true) {
		cout<<"******Busqueda de Automovil******";
		cout<<"*********************************";
		saltosDeLinea(2);			
		mensajeConValorEnConsola("N� Codigo: ", codigoAutoRent);
		
		for(int indice = 0; indice < 5; indice++) {		
			if (arregloJuegos[indice][0] == codigoAutoRent) {
				Modelo = arregloJuegos[indice][1];
				anio = arregloJuegos[indice][2];
				mensajePantalla("--> " + descripcionJuego);
				return true;
			}
		}		
			
		bool continuar = false;
		while(continuar == false) {
			system("cls");
			
			string opcion = "";
			mensajeConValorEnConsola("Automovil no encontrado, desea continuar buscando s/n? ", opcion);
			
			if (opcion == "s" || opcion == "S") {
				continuar = true;
				system("cls");
			}
			if (opcion == "n" || opcion == "N") {
				return false;
			}		
		}
	}
}

