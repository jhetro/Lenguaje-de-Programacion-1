#include <iostream>
#include "autoRent.h"
#include "autoRentMenu.h"
#include "welcome.h"
#include "servicioCliente.h"
#include "ventaAutomovil.h"


using namespace std;

void autoRent() {
	system("cls");
	
	cout << "*****AUTORENT*****" << endl;
	cout << "******************" << endl;
	saltosDeLinea(2);	
	
	bool salir = false;
	//Ingreso de Busqueda del Cliente con Automovil en Renta  
	while(salir == false) {		 
		system("cls");   			
		
		char* codigoC;
		char* cliente;
		if (buscarCliente(codigo, cliente) == false) {
			return;
		}
		
		system("cls");   	
		
		char* codigoAutoRent;
		char* Modelo;
		char* anio;
		if (buscarJuego(codigoAutoRent, Modelo, anio) == false) {
			return;
		}	
		
		system("cls");
		int ciclos;
	
		cout<<"AUTOMOVIL RENTADO"<<endl;
	
		cout<<"Codigo" + codigo;
		cout<<"-->" + Cliente
		saltosDeLinea(1);				
		cout<<"Auto en Renta " + codigoAutoRent;
		cout"-->" + Modelo;
		cout"-->" + anio;
		saltosDeLinea(1);				
		cout"Segun reglamento ARR-001 el Auto se Renta en un lapso de 2 Dias";
		
		saltosDeLinea(3);				
		string opcion;
		cout << "Si desea salir Presione [S] o [s]" << endl;	
		cin>>opcion;
		
		if (opcion == "S" || opcion == "s") {
			salir = true;
		}
	}
}

