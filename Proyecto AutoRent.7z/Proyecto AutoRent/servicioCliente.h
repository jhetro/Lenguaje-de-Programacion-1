void servicioCliente();
bool cliente(char* &codigoC, char* &cliente);
