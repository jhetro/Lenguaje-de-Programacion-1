#include <iostream>
#include "accesoCuenta.h"
#include "welcome.h"



using namespace std;

bool login() {

	char usuario;
	bool acceso = false;
	int I = 0;
	int ciclos;
	
	
	while (acceso == false) {
		system("cls");		
	 	welcome();
		
	
		
		cout << "Ingrese:\n\n [A] - Si eres Usuario Administrador\n\n [C]- si eres Cliente Usuario "<<endl;
		cin >> usuario;
		cout<<endl<<endl;
		
		switch (usuario){
			case 'A':
				acceso=true;
				break;
			case 'C':
				acceso=true;
				break;
				default:
			if (I == 2) {
			cout << "Contrase�a no almacenada en el sistema ." << endl;
			
			return false;
		}
		}
		
					
		
		I++;		
	}
	
	system("cls");
	
	return true;
}

