void welcome();
void saltosDeLinea(int ciclos);


