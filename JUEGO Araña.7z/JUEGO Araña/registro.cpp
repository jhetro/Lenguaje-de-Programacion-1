#include <stdio.h>
#include <conio.h>

bool baseDeRegistro() {
	FILE *doc;
	char jug[10];
	int n=1;
	doc = fopen ("Jug.txt","a+");

	
		if (doc == NULL){
		printf("Error de apertura");
		return 1;
	}
while ( (n = getc(doc)) != EOF){
	fputc(n,doc);
	return 0;
	
}
	
}

bool mustraDatos(){
FILE *nevo;
nevo = fopen ("Jug.txt","r");
int c;

while ( (c = getc(nevo)) != EOF){
	
	if (nevo == NULL){
		printf("Error de apertura");
		return 1;
	}
	
	if(c == '\n') printf("\n");
	else printf("%c ", c);
}
	fclose(nevo);
	return 0;
}

