#include <iostream>
#include <conio.h>
#include <stdlib.h>
#include "Auxiliares.h"
#include "barraMenu.h"
using namespace std;
#define clavetrue 12345

int i=0;
int claveacceso;
int cont;
main(void){
	system("COLOR 0B0");
	
	do{
		titulo();
		alinear(1);
		cout<<"INGRESE LA CLAVE DE ACCESO";
		alinear(1);
		cin>>claveacceso;
		alinear(1);
		i++;
		if (claveacceso!=clavetrue){
			system ("Cls");
			cout<<"Acceso Denegado";
			alinear(1);

		} if (i==3){
			return false;
		}
		
	}while(claveacceso!=clavetrue);
		alinear(1);
		system ("Cls");
		cout<<"Acceso Concedido";
		alinear(1);
		cout << "presione enter --> ";
		getch();
		system ("Cls");
		menu();
}
