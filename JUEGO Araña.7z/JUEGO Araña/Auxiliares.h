void alinear(int ciclos);
void titulo();
