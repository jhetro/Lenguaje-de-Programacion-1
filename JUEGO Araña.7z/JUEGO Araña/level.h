void geografia();
void personajes();
void futbol();

