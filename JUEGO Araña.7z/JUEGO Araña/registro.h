bool baseDeRegistro();
bool mustraDatos();
