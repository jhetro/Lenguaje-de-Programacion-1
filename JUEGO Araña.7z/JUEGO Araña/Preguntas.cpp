#include <iostream>
#include<stdlib.h>
#include <conio.h>
#include "preguntas.h"
#include "registro.h"
#include "level.h"
#include "Auxiliares.h"
using namespace std;

	int porc;
	int resp1,resp2,resp3,resp4,resp5;
	int resp;
	int corr=0;
	int inc=0;
	char salir;
	string j[10];
	
//Preguntas Geografia
	void Gpreguntauno(){
				
				
				system ("Cls");
				float res5;float res4;float res3;float res2;float res1;
				int resp1,resp2,resp3,resp4,resp5;
				cout << "---Primera Pregunta---";
				resp = (rand()%5)+1;
				alinear(1);
					
				if ((resp==1)) {
					cout << "�Como se llama el pico mas alto de Am�rica, que puedes conocer en Argentina?" << endl;
					cout << "1. Aconcagua." << endl;
					cout << "2. La patagonia" << endl;
					cout << "3. Los Apes" << endl;
					cout << "4. zion" << endl;
					cin >> res1;
					if ((res1==1)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				
				if ((resp==2)) {
					cout << " �A qu� continente pertenece la Isla de Madagascar?" << endl;
					cout << "1. oceania"<< endl;
					cout << "2. europa" << endl;
					cout << "3. africa" << endl;
					cout << "4. pangea" << endl;
					cin >> res2;
					if ((res2==3)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc = inc+1;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==3)) {
					cout << "  �En qu� pa�s esta la Esfinge de Gizeh?" << endl;
					cout << "1. Egipto." << endl;
					cout << "2. Emitratos Arabes" << endl;
					cout << "3. Etiopia" << endl;
					cout << "4. Grecia" << endl;
					cin >> res3;
					if ((res3==1)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==4)) {
					cout << "�Cual es la capital de Uruguay?" << endl;
					cout << "1. Montrial" << endl;
					cout << "2. Montevideo." << endl;
					cout << "3. Machupichu" << endl;
					cout << "4. Santiago" << endl;
					cin >> res4;
					if ((res4==2)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==5)) {
					cout << " Trinidad y Tobago son dos islas americanas de habla inglesa situadas en el mar" << endl;
					cout << "1. Mediterranio" << endl;
					cout << "2. Muerto" << endl;
					cout << "3. Caribe" << endl;
					cout << "4. Baja mar" << endl;
					cin >> res5;
					if ((res5==3)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
			
			}
void Gpreguntados(){
				system ("Cls");
				float res6,res7,res8,res9,res10;
				int resp1,resp2,resp3,resp4,resp5;
				cout << "---Segunda Pregunta---" << endl;
				resp = (rand()%5)+1;
				if ((resp==1)) {
					cout << " �En qu� pa�s europeo se encuentra el puerto de Liverpool?" << endl;
					cout << "1.Inglaterra" << endl;
					cout << "2.Irlanda" << endl;
					cout << "3.Nueva Zelanda" << endl;
					cout << "4.Alemania" << endl;
					cin >> res6;
					if ((res6==1)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==2)) {
					cout << "  �Cual es el mas grande de los sat�lites del Sistema Solar?" << endl;
					cout << "1. Jupiter" << endl;
					cout << "2. Sol" << endl;
					cout << "3. Luna." << endl;
					cout << "4. Tierra" << endl;
					cin >> res7;
					if ((res7==3)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==3)) {
					cout << "�Que tibu indigena levanto civilizacion en el occidente de Honduras" << endl;
					cout << "1. Olmeca" << endl;
					cout << "2. Maya" << endl;
					cout << "3. Inca" << endl;
					cout << "4. Lenca" << endl;
					cin >> res8;
					if ((res8==2)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==4)) {
					cout << "�Cual de las ciudades no se encuentra en Colombia?" << endl;
					cout << "1. Cali" << endl;
					cout << "2. Soledad" << endl;
					cout << "3. Leticia" << endl;
					cout << "4. Cordoba" << endl;
					cin >> res9;
					if ((res9==4)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==5)) {
					cout << "�Donde esta ubicada la ciudad de turin" << endl;
					cout << "1. Francia" << endl;
					cout << "2. Italia" << endl;
					cout << "3. Begica" << endl;
					cin >> res10;
					if ((res10==2)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				
			}
void Gpreguntatres(){
				system ("Cls");
				float res11,res12,res13,res14,res15;
				int resp1,resp2,resp3,resp4,resp5;
				cout << "" << endl;
				cout << "---Tercera Pregunta---" << endl;
				resp = (rand()%5)+1;
					if ((resp==1)) {
					cout << "" << endl;
					cout << " �Cual es la capital de Canada" << endl;
					cout << "1. Ottawa" << endl;
					cout << "4. Toronto" << endl;
					cout << "3. Montrial" << endl;
					cin >> res11;
					if ((res11==1)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==2)) {
					cout << "Meseta donde se ejecuto la primera gerra humana" << endl;
					cout << "1. Marruecos " << endl;
					cout << "2. Valle de Rio bravo" << endl;
					cout << "3. Balcanes" << endl;
					cout << "4. Meguido" << endl;
					cin >> res12;
					if ((res12==4)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==3)) {
					cout << "�Cual es la circunferencia de la Tierra medida por la l�nea del Ecuador?" << endl;
					cout << "1. 2 millas" << endl;
					cout << "2. 0.089km" << endl;
					cout << "3. 1800 km" << endl;
					cout << "4. 40.075km" << endl;
					cin >> res13;
					if ((res13==4)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==4)) {
					cout << "�En qu� pa�s se encuentra el Canal de Suez?" << endl;
					cout << "1. Qatar" << endl;
					cout << "2. Israel" << endl;
					cout << "3. Egipto" << endl;
					cout << "4. Ninguna de las anteriores" << endl;
					cin >> res14;
					if ((res14==3)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==5)) {
					cout << "�Cual de los siguientes no es un continente?" << endl;
					cout << "1. Australia" << endl;
					cout << "2. Antartida" << endl;
					cout << "3. Ocean�a" << endl;
					cout << "4. Europa" << endl;
					cin >> res15;
					if ((res15==1)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				
}
void Gpreguntacuatro(){	
				system ("Cls");
				float res16,res17,res18,res19,res20;
				int resp1,resp2,resp3,resp4,resp5;
				cout << "" << endl;
				cout << "---Cuarta Pregunta---" << endl;
				resp = (rand()%5)+1;
				if ((resp==1)) {
					cout << "No es un pa�s de Asia:" << endl;
					cout << "1. Grecia" << endl;
					cout << "2. China" << endl;
					cout << "3. Mongolia" << endl;
					cout << "4. Laos" << endl;
					cin >> res16;
					if ((res16==1)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==2)) {
					cout << "�Qu� pa�s no forma parte de la Pen�nsula Arabiga?" << endl;
					cout << "1. Amperios" << endl;
					cout << "2. Hercios" << endl;
					cout << "3. Voltios" << endl;
					cout << "4. Watts" << endl;
					cin >> res17;
					if ((res17==2)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==3)) {
					cout << "En que pais se profesa la religion Cristiana" << endl;
					cout << "1. Arabia Saudita" << endl;
					cout << "2. Iran" << endl;
					cout << "3. Yemen" << endl;
					cout << "4. Turquia" << endl;
					cin >> res18;
					if ((res18==4)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==4)) {
					cout << "�Cual es la edad aproximada de la Tierra?" << endl;
					cout << "1. 4.470 millones de a�os" << endl;
					cout << "2. 3 billones de a�os" << endl;
					cout << "3. 7.45 millas nauticas" << endl;
					cout << "4. nuinguna es correcta" << endl;
					cin >> res19;
					if ((res19==1)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==5)) {
					cout << "el mar conpigmentacion debido a un alga endemica se llama" << endl;
					cout << "1. Mar Basco" << endl;
					cout << "2. Mar Rojo" << endl;
					cout << "3. Mar Mediterranio" << endl;
					cout << "4. Caribe" << endl;
					cin >> res20;
					if ((res20==2)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
			
}
void Gpreguntacinco(){
				system ("Cls");
				float res21,res22,res23,res24,res25;
				int resp1,resp2,resp3,resp4,resp5;
				cout << "" << endl;
				cout << "---Quinta Pregunta---" << endl;
				resp = (rand()%5)+1;
				if ((resp==1)) {
					cout << "�Qu� hombre puso por primera vez el pie en la Luna?" << endl;
					cout << "1. Adofth" << endl;
					cout << "2. Lindberg " << endl;
					cout << "3. Armstrong" << endl;
					cout << "4. Bengamin Franklin" << endl;
					cin >> res21;
					if ((res21==3)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==2)) {
					cout << "�Qu� pueblo mandaba Atila?" << endl;
					cout << "1. Vikingos" << endl;
					cout << "2. Romanos " << endl;
					cout << "3. Hunos" << endl;
					cout << "4. Persas" << endl;
					cin >> res22;
					if ((res22==3)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==3)) {
					cout << "�En qu� cadena monta�osa encontramos la cima mas alta del mundo?" << endl;
					cout << "1. Los Andes" << endl;
					cout << "2. Los Aples" << endl;
					cout << "3. Patagonia" << endl;
					cout << "4. El Himalaya" << endl;
					cin >> res23;
					if ((res23==4)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==4)) {
					cout << "�En qu� continente podemos encontrar Senegal?" << endl;
					cout << "1. Antartida" << endl;
					cout << "2. Autralia" << endl;
					cout << "3. Africa" << endl;
					cout << "4. Europa" << endl;
					cin >> res24;
					if ((res24==3)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==5)) {
					cout << "Capital de Belice" << endl;
					cout << "1. BelmoPan" << endl;
					cout << "2. Belmon" << endl;
					cout << "3. Port Royal" << endl;
					cout << "4. Ninguna de las anteriores" << endl;
					cin >> res25;
					if ((res25==1)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
			}
//Preguntas Personajes
	void Ppreguntauno(){
				
				
				system ("Cls");
				float res5;float res4;float res3;float res2;float res1;
				int resp1,resp2,resp3,resp4,resp5;
				cout << "---Primera Pregunta---" << endl;
				resp = (rand()%5)+1;
					
				if ((resp==1)) {
					cout << "como se llamba el presidente de US cuando tu naciste" << endl;
					cout << "1. Donalth Trump." << endl;
					cout << "2. Gorge w Bush" << endl;
					cout << "3. Jimy Carter" << endl;
					cout << "4. Barack Obama" << endl;
					cin >> res1;
					if ((res1==1)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				
				if ((resp==2)) {
					cout << " que fue Charles Chaplin" << endl;
					cout << "1. Actor"<< endl;
					cout << "2. Comediante" << endl;
					cout << "3. Era Mudo" << endl;
					cout << "4. A y B son Correctas" << endl;
					cin >> res2;
					if ((res2==4)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc = inc+1;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==3)) {
					cout << "  quien interpreto a selena en su pelicula bigrafica" << endl;
					cout << "1. jennyfer Lopez." << endl;
					cout << "2. Agelina Jo Lee" << endl;
					cout << "3. Julia Roberths" << endl;
					cout << "4. Cameron Diaz" << endl;
					cin >> res3;
					if ((res3==1)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==4)) {
					cout << "  fue una de la mujeres mas iminentes de la fisica y quimica" << endl;
					cout << "1. Madame Curi" << endl;
					cout << "2. Juana de Arco." << endl;
					cout << "3. Madre Teresa de Calcuta" << endl;
					cout << "4. la chupitos" << endl;
					cin >> res4;
					if ((res4==1)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==5)) {
					cout << "  de que pais era Gael Garcia Marquez" << endl;
					cout << "1. Venezolano" << endl;
					cout << "2. Mexicano" << endl;
					cout << "3. Colombiano" << endl;
					cout << "4. Cubano" << endl;
					cin >> res5;
					if ((res5==3)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
			
			}
void Ppreguntados(){
				system ("Cls");
				float res6,res7,res8,res9,res10;
				int resp1,resp2,resp3,resp4,resp5;
				cout << "---Segunda Pregunta---" << endl;
				resp = (rand()%5)+1;
				if ((resp==1)) {
					cout << " quien fue Franklin D Roosevelt" << endl;
					cout << "1. Primer Ministro de Inglaterra" << endl;
					cout << "2. Uno de los tripulantes del Titanic" << endl;
					cout << "3. Un Militar de la segunda guerra mundial" << endl;
					cout << "4. Presidente de US" << endl;
					cin >> res6;
					if ((res6==4)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==2)) {
					cout << "  �en que decada llego luis Anstrom a la luna" << endl;
					cout << "1. 90's" << endl;
					cout << "2. 70's" << endl;
					cout << "3. 60's." << endl;
					cout << "4. ninguna es correcta" << endl;
					cin >> res7;
					if ((res7==3)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==3)) {
					cout << "�Cual era la nacionalidad de Hitler" << endl;
					cout << "1. Alemana" << endl;
					cout << "2. Autriaca" << endl;
					cout << "3. Belga" << endl;
					cout << "4. Holandesa" << endl;
					cin >> res8;
					if ((res8==2)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==4)) {
					cout << "Contra que injusticia lucho Nelson Mandela" << endl;
					cout << "1. ANC" << endl;
					cout << "2. Los Derechos de la Mujeres" << endl;
					cout << "3. Discriminacion sexual" << endl;
					cout << "4. Apartheid" << endl;
					cin >> res9;
					if ((res9==4)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==5)) {
					cout << "En que a�o llego al poder Fidel Castro" << endl;
					cout << "1. 1944" << endl;
					cout << "2. 1959" << endl;
					cout << "3. 1949" << endl;
					cin >> res10;
					if ((res10==2)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				
			}
void Ppreguntatres(){
				system ("Cls");
				float res11,res12,res13,res14,res15;
				int resp1,resp2,resp3,resp4,resp5;
				cout << "" << endl;
				cout << "---Tercera Pregunta---" << endl;
				resp = (rand()%5)+1;
					if ((resp==1)) {
					cout << "" << endl;
					cout << " Conciderado renovador de los juegos olimpicos " << endl;
					cout << "1. Pierre de Cubertin" << endl;
					cout << "4. Michel Jeffrey" << endl;
					cout << "3. George German" << endl;
					cin >> res11;
					if ((res11==1)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==2)) {
					cout << " Quien Fue Sammuel Finley "<< endl;
					cout << "1. medido forense" << endl;
					cout << "2. Culumnista del diario el clarin" << endl;
					cout << "3. Inventor del telefono celular" << endl;
					cout << "4. Inventor de telegrafo" << endl;
					cin >> res12;
					if ((res12==4)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==3)) {
					cout << "quien fue el protagonista de Titanic" << endl;
					cout << "1. Jack Black" << endl;
					cout << "2. Johnny Deep" << endl;
					cout << "3. Brad Pit" << endl;
					cout << "4. Leonardo Di Caprio" << endl;
					cin >> res13;
					if ((res13==4)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==4)) {
					cout << "  " << endl;
					cout << "1. Qatar" << endl;
					cout << "2. Israel" << endl;
					cout << "3. Egipto" << endl;
					cout << "4. Ninguna de las anteriores" << endl;
					cin >> res14;
					if ((res14==3)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==5)) {
					cout << "�Cual de los siguientes no es un continente?" << endl;
					cout << "1. Australia" << endl;
					cout << "2. Antartida" << endl;
					cout << "3. Ocean�a" << endl;
					cout << "4. Europa" << endl;
					cin >> res15;
					if ((res15==1)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				
}
void Ppreguntacuatro(){	
				system ("Cls");
				float res16,res17,res18,res19,res20;
				int resp1,resp2,resp3,resp4,resp5;
				cout << "" << endl;
				cout << "---Cuarta Pregunta---" << endl;
				resp = (rand()%5)+1;
				if ((resp==1)) {
					cout << "No es un pa�s de Asia:" << endl;
					cout << "1. Grecia" << endl;
					cout << "2. China" << endl;
					cout << "3. Mongolia" << endl;
					cout << "4. Laos" << endl;
					cin >> res16;
					if ((res16==1)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==2)) {
					cout << "�Qu� pa�s no forma parte de la Pen�nsula Arabiga?" << endl;
					cout << "1. Amperios" << endl;
					cout << "2. Hercios" << endl;
					cout << "3. Voltios" << endl;
					cout << "4. Watts" << endl;
					cin >> res17;
					if ((res17==2)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==3)) {
					cout << "En que pais se profesa la religion Cristiana" << endl;
					cout << "1. Arabia Saudita" << endl;
					cout << "2. Iran" << endl;
					cout << "3. Yemen" << endl;
					cout << "4. Turquia" << endl;
					cin >> res18;
					if ((res18==4)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==4)) {
					cout << "�Cual es la edad aproximada de la Tierra?" << endl;
					cout << "1. 4.470 millones de a�os" << endl;
					cout << "2. 3 billones de a�os" << endl;
					cout << "3. 7.45 millas nauticas" << endl;
					cout << "4. nuinguna es correcta" << endl;
					cin >> res19;
					if ((res19==1)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==5)) {
					cout << "el mar conpigmentacion debido a un alga endemica se llama" << endl;
					cout << "1. Mar Basco" << endl;
					cout << "2. Mar Rojo" << endl;
					cout << "3. Mar Mediterranio" << endl;
					cout << "4. Caribe" << endl;
					cin >> res20;
					if ((res20==2)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
			
}
void Ppreguntacinco(){
				system ("Cls");
				float res21,res22,res23,res24,res25;
				int resp1,resp2,resp3,resp4,resp5;
				cout << "" << endl;
				cout << "---Quinta Pregunta---" << endl;
				resp = (rand()%5)+1;
				if ((resp==1)) {
					cout << "�Qu� hombre puso por primera vez el pie en la Luna?" << endl;
					cout << "1. Adofth" << endl;
					cout << "2. Lindberg " << endl;
					cout << "3. Armstrong" << endl;
					cout << "4. Bengamin Franklin" << endl;
					cin >> res21;
					if ((res21==3)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==2)) {
					cout << "�Qu� pueblo mandaba Atila?" << endl;
					cout << "1. Vikingos" << endl;
					cout << "2. Romanos " << endl;
					cout << "3. Hunos" << endl;
					cout << "4. Persas" << endl;
					cin >> res22;
					if ((res22==3)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==3)) {
					cout << "�En qu� cadena monta�osa encontramos la cima mas alta del mundo?" << endl;
					cout << "1. Los Andes" << endl;
					cout << "2. Los Aples" << endl;
					cout << "3. Patagonia" << endl;
					cout << "4. El Himalaya" << endl;
					cin >> res23;
					if ((res23==4)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==4)) {
					cout << "�En qu� continente podemos encontrar Senegal?" << endl;
					cout << "1. Antartida" << endl;
					cout << "2. Autralia" << endl;
					cout << "3. Africa" << endl;
					cout << "4. Europa" << endl;
					cin >> res24;
					if ((res24==3)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==5)) {
					cout << "Capital de Belice" << endl;
					cout << "1. BelmoPan" << endl;
					cout << "2. Belmon" << endl;
					cout << "3. Port Royal" << endl;
					cout << "4. Ninguna de las anteriores" << endl;
					cin >> res25;
					if ((res25==1)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
			}
//Preguntas Futbol
void Fpreguntauno(){
				
				
				system ("Cls");
				float res5;float res4;float res3;float res2;float res1;
				int resp1,resp2,resp3,resp4,resp5;
				cout << "---Primera Pregunta---" << endl;
				resp = (rand()%5)+1;
					
				if ((resp==1)) {
					cout << "1.�Como se llama el pico mas alto de Am�rica, que puedes conocer en Argentina?" << endl;
					cout << "1. Aconcagua." << endl;
					cout << "2. La patagonia" << endl;
					cout << "3. Los Apes" << endl;
					cout << "4. zion" << endl;
					cin >> res1;
					if ((res1==1)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				
				if ((resp==2)) {
					cout << " �A qu� continente pertenece la Isla de Madagascar?" << endl;
					cout << "1. oceania"<< endl;
					cout << "2. europa" << endl;
					cout << "3. africa" << endl;
					cout << "4. pangea" << endl;
					cin >> res2;
					if ((res2==3)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc = inc+1;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==3)) {
					cout << "  �En qu� pa�s esta la Esfinge de Gizeh?" << endl;
					cout << "1. Egipto." << endl;
					cout << "2. Emitratos Arabes" << endl;
					cout << "3. Etiopia" << endl;
					cout << "4. Grecia" << endl;
					cin >> res3;
					if ((res3==1)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==4)) {
					cout << "�Cual es la capital de Uruguay?" << endl;
					cout << "1. Montrial" << endl;
					cout << "2. Montevideo." << endl;
					cout << "3. Machupichu" << endl;
					cout << "4. Santiago" << endl;
					cin >> res4;
					if ((res4==2)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==5)) {
					cout << " Trinidad y Tobago son dos islas americanas de habla inglesa situadas en el mar" << endl;
					cout << "1. Mediterranio" << endl;
					cout << "2. Muerto" << endl;
					cout << "3. Caribe" << endl;
					cout << "4. Baja mar" << endl;
					cin >> res5;
					if ((res5==3)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
			
			}
void Fpreguntados(){
				system ("Cls");
				float res6,res7,res8,res9,res10;
				int resp1,resp2,resp3,resp4,resp5;
				cout << "---Segunda Pregunta---" << endl;
				resp = (rand()%5)+1;
				if ((resp==1)) {
					cout << " �En qu� pa�s europeo se encuentra el puerto de Liverpool?" << endl;
					cout << "1.Inglaterra" << endl;
					cout << "2.Irlanda" << endl;
					cout << "3.Nueva Zelanda" << endl;
					cout << "4.Alemania" << endl;
					cin >> res6;
					if ((res6==1)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==2)) {
					cout << "  �Cual es el mas grande de los sat�lites del Sistema Solar?" << endl;
					cout << "1. Jupiter" << endl;
					cout << "2. Sol" << endl;
					cout << "3. Luna." << endl;
					cout << "4. Tierra" << endl;
					cin >> res7;
					if ((res7==3)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==3)) {
					cout << "�Que tibu indigena levanto civilizacion en el occidente de Honduras" << endl;
					cout << "1. Olmeca" << endl;
					cout << "2. Maya" << endl;
					cout << "3. Inca" << endl;
					cout << "4. Lenca" << endl;
					cin >> res8;
					if ((res8==2)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==4)) {
					cout << "�Cual de las ciudades no se encuentra en Colombia?" << endl;
					cout << "1. Cali" << endl;
					cout << "2. Soledad" << endl;
					cout << "3. Leticia" << endl;
					cout << "4. Cordoba" << endl;
					cin >> res9;
					if ((res9==4)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==5)) {
					cout << "�Donde esta ubicada la ciudad de turin" << endl;
					cout << "1. Francia" << endl;
					cout << "2. Italia" << endl;
					cout << "3. Begica" << endl;
					cin >> res10;
					if ((res10==2)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				
			}
void Fpreguntatres(){
				system ("Cls");
				float res11,res12,res13,res14,res15;
				int resp1,resp2,resp3,resp4,resp5;
				cout << "" << endl;
				cout << "---Tercera Pregunta---" << endl;
				resp = (rand()%5)+1;
					if ((resp==1)) {
					cout << "" << endl;
					cout << " �Cual es la capital de Canada" << endl;
					cout << "1. Ottawa" << endl;
					cout << "4. Toronto" << endl;
					cout << "3. Montrial" << endl;
					cin >> res11;
					if ((res11==1)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==2)) {
					cout << "Meseta donde se ejecuto la primera gerra humana" << endl;
					cout << "1. Marruecos " << endl;
					cout << "2. Valle de Rio bravo" << endl;
					cout << "3. Balcanes" << endl;
					cout << "4. Meguido" << endl;
					cin >> res12;
					if ((res12==4)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==3)) {
					cout << "�Cual es la circunferencia de la Tierra medida por la l�nea del Ecuador?" << endl;
					cout << "1. 2 millas" << endl;
					cout << "2. 0.089km" << endl;
					cout << "3. 1800 km" << endl;
					cout << "4. 40.075km" << endl;
					cin >> res13;
					if ((res13==4)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==4)) {
					cout << "�En que pa�s se encuentra el Canal de Suez?" << endl;
					cout << "1. Qatar" << endl;
					cout << "2. Israel" << endl;
					cout << "3. Egipto" << endl;
					cout << "4. Ninguna de las anteriores" << endl;
					cin >> res14;
					if ((res14==3)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==5)) {
					cout << "�Cual de los siguientes no es un continente?" << endl;
					cout << "1. Australia" << endl;
					cout << "2. Antartida" << endl;
					cout << "3. Ocean�a" << endl;
					cout << "4. Europa" << endl;
					cin >> res15;
					if ((res15==1)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				
}
void Fpreguntacuatro(){	
				system ("Cls");
				float res16,res17,res18,res19,res20;
				int resp1,resp2,resp3,resp4,resp5;
				cout << "" << endl;
				cout << "---Cuarta Pregunta---" << endl;
				resp = (rand()%5)+1;
				if ((resp==1)) {
					cout << "No es un pa�s de Asia:" << endl;
					cout << "1. Grecia" << endl;
					cout << "2. China" << endl;
					cout << "3. Mongolia" << endl;
					cout << "4. Laos" << endl;
					cin >> res16;
					if ((res16==1)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==2)) {
					cout << "�Que pa�s no forma parte de la Pen�nsula Arabiga?" << endl;
					cout << "1. Amperios" << endl;
					cout << "2. Hercios" << endl;
					cout << "3. Voltios" << endl;
					cout << "4. Watts" << endl;
					cin >> res17;
					if ((res17==2)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==3)) {
					cout << "En que pais se profesa la religion Cristiana" << endl;
					cout << "1. Arabia Saudita" << endl;
					cout << "2. Iran" << endl;
					cout << "3. Yemen" << endl;
					cout << "4. Turquia" << endl;
					cin >> res18;
					if ((res18==4)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==4)) {
					cout << "�Cual es la edad aproximada de la Tierra?" << endl;
					cout << "1. 4.470 millones de a�os" << endl;
					cout << "2. 3 billones de a�os" << endl;
					cout << "3. 7.45 millas nauticas" << endl;
					cout << "4. nuinguna es correcta" << endl;
					cin >> res19;
					if ((res19==1)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==5)) {
					cout << "el mar conpigmentacion debido a un alga endemica se llama" << endl;
					cout << "1. Mar Basco" << endl;
					cout << "2. Mar Rojo" << endl;
					cout << "3. Mar Mediterranio" << endl;
					cout << "4. Caribe" << endl;
					cin >> res20;
					if ((res20==2)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
			
}
void Fpreguntacinco(){
				system ("Cls");
				float res21,res22,res23,res24,res25;
				int resp1,resp2,resp3,resp4,resp5;
				cout << "" << endl;
				cout << "---Quinta Pregunta---" << endl;
				resp = (rand()%5)+1;
				if ((resp==1)) {
					cout << "�Que hombre puso por primera vez el pie en la Luna?" << endl;
					cout << "1. Adofth" << endl;
					cout << "2. Lindberg " << endl;
					cout << "3. Armstrong" << endl;
					cout << "4. Bengamin Franklin" << endl;
					cin >> res21;
					if ((res21==3)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==2)) {
					cout << "�Que pueblo mandaba Atila?" << endl;
					cout << "1. Vikingos" << endl;
					cout << "2. Romanos " << endl;
					cout << "3. Hunos" << endl;
					cout << "4. Persas" << endl;
					cin >> res22;
					if ((res22==3)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==3)) {
					cout << "�En que cadena monta�osa encontramos la cima mas alta del mundo?" << endl;
					cout << "1. Los Andes" << endl;
					cout << "2. Los Aples" << endl;
					cout << "3. Patagonia" << endl;
					cout << "4. El Himalaya" << endl;
					cin >> res23;
					if ((res23==4)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==4)) {
					cout << "�En que continente podemos encontrar Senegal?" << endl;
					cout << "1. Antartida" << endl;
					cout << "2. Autralia" << endl;
					cout << "3. Africa" << endl;
					cout << "4. Europa" << endl;
					cin >> res24;
					if ((res24==3)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
				if ((resp==5)) {
					cout << "Capital de Belice" << endl;
					cout << "1. BelmoPan" << endl;
					cout << "2. Belmon" << endl;
					cout << "3. Port Royal" << endl;
					cout << "4. Ninguna de las anteriores" << endl;
					cin >> res25;
					if ((res25==1)) {
						corr++;
						cout << "Tu respuesta es correcta" << endl;
					} else {
						inc++;
						cout << "Tu respuesta es incorrecta" << endl;
					}
				}
			}
void resultados(){

	while (porc = (corr/5)*100){
			
				if (porc==100) {
					cout << "Tu resultado es Insuperable" << endl;
					cout << "" << endl;
					baseDeRegistro();
					
				}
				if (porc>80 && porc<100) {
					cout << "Tu resultado es Bueno" << endl;
				}
				if (porc>60 && porc<=80) {
					cout << "Tu resultado es Aceptable" << endl;
				}
				if (porc>40 && porc<=60) {
					cout << "Tu resultado es Malo" << endl;
				}
				if (porc>20 && porc<=40) {
					cout << "Tu resultado es Pesimo" << endl;
				}
				if (porc>=0 && porc<=20) {
					cout << "No intentes sin conocimiento" << endl;
				}	
			
				cout << "********** Resultados **********" << endl;
				cout << "" << endl;
				cout << "Respuestas correctas: " << corr << endl;
				cout << "Respuestas incorrectas: " << inc << endl;
				cout << "Respondiste correctamente el " << porc << "% de las preguntas" << endl;
				system ("pause");
				system ("Cls");
}
}




