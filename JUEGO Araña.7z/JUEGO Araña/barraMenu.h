void menupartida();
void menu();
