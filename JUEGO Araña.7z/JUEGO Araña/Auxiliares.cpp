#include <iostream>
#include <fstream>
#include "Auxiliares.h"
FILE *doc;
using namespace std;

void alinear(int ciclos)
{
	for (int i=1;i<=ciclos;i++){
		cout<<endl;
	}
}
void titulo(){
	cout<<"WELCOME TO:";
	alinear(2);
cout<<"*************************8******8*****8***********************"<<endl;
cout<<" SSSSSSS    PPPPPPP   ####8     8    8      8                *"<<endl;
cout<<"******************PP  #### 8 ***8***8 ****8***8***************" <<endl;                                         
cout<<" SS         PP    PPP       8   8  8    8                    *"<<endl;      
cout<<"  SS        PP     PP DDDDDDDDDDDDD   8               	     *"<<endl;     
cout<<"   SSSSSSS  PP     PP IIII  DDD DDD 8                        *"<<endl;     
cout<<"        SS  PPPPPPPP  IIII  DDD DDDD EEEEEE                  *"<<endl;     
cout<<"        SS  PP        IIII  DD   DDD EE   EE                 *"<<endl;     
cout<<" SSSSSSSSS  PP        IIII  DD   DDD EE EEEE          	     *"<<endl;     
cout<<"            PP        IIII  DDD DDDD EE EE    RRRRR    	     *"<<endl;     
cout<<"            PP        IIII  DDD DDD  EE     RRR  RRR         *"<<endl;
cout<<"                      DDDDDDDDDDDD   EE     RRR   RR         *"<<endl;
cout<<"                           8  8  8   EEEEE  RRR  RRR         *"<<endl;
cout<<"                          8   8   8         RRR RR           *"<<endl;
cout<<"                         8    8    8      8 RRR   RRR        *"<<endl;
cout<<"                        8     8     8  8    RRR    RRR       *"<<endl;
cout<<"                        8     8      8      RRR     RRR      *"<<endl;
cout<<"**************************************************************"<<endl;
cout<<"**************************************************************"<<endl;
}


	
	
	
	

